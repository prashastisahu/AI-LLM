"""
AWS S3 service: upload user images, return S3 keys.
Images are stored with a UUID key and never exposed publicly —
only pre-signed URLs are generated for temporary access.
"""
import uuid
import structlog
import boto3
from botocore.exceptions import ClientError

from app.core.config import get_settings

logger = structlog.get_logger()
settings = get_settings()


def _s3_client():
    return boto3.client(
        "s3",
        region_name=settings.aws_region,
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
    )


def upload_image(image_bytes: bytes, media_type: str) -> str:
    """
    Upload image bytes to S3. Returns the S3 object key.
    media_type: e.g. "image/jpeg", "image/png"
    """
    ext = media_type.split("/")[-1].replace("jpeg", "jpg")
    key = f"uploads/{uuid.uuid4()}.{ext}"

    client = _s3_client()
    client.put_object(
        Bucket=settings.s3_bucket_name,
        Key=key,
        Body=image_bytes,
        ContentType=media_type,
        # No ACL — bucket is private, access only via pre-signed URLs
    )
    logger.info("s3.upload", key=key, size_bytes=len(image_bytes))
    return key


def get_presigned_url(key: str, expiry_seconds: int = 3600) -> str:
    """Generate a pre-signed URL for temporary access to an uploaded image."""
    client = _s3_client()
    url = client.generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.s3_bucket_name, "Key": key},
        ExpiresIn=expiry_seconds,
    )
    return url


def delete_image(key: str) -> None:
    """Delete an image from S3 (e.g. after processing if not storing)."""
    try:
        client = _s3_client()
        client.delete_object(Bucket=settings.s3_bucket_name, Key=key)
        logger.info("s3.delete", key=key)
    except ClientError as e:
        logger.warning("s3.delete_error", key=key, error=str(e))
