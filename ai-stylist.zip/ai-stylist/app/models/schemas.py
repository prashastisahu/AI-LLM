from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class Occasion(str, Enum):
    everyday = "everyday"
    office = "office"
    evening = "evening"
    special = "special"
    outdoor = "outdoor"


class Aesthetic(str, Enum):
    natural = "natural"
    classic = "classic"
    bold = "bold"
    romantic = "romantic"
    edgy = "edgy"


class Budget(str, Enum):
    any = "any"
    drugstore = "drugstore"
    mid = "mid"
    luxury = "luxury"


# ── Request ──────────────────────────────────────────────────────────────────

class StyleRequest(BaseModel):
    occasion: Occasion = Occasion.everyday
    aesthetic: Aesthetic = Aesthetic.natural
    skin_tone_hint: Optional[str] = None  # None = auto-detect from image
    budget: Budget = Budget.any


# ── Vision analysis output ────────────────────────────────────────────────────

class ColorSwatch(BaseModel):
    hex: str
    name: str
    use: str  # e.g. "lips", "eyes", "blush"


class ColorStory(BaseModel):
    palette: list[ColorSwatch]
    description: str


class VisualProfile(BaseModel):
    skin_tone: str
    undertone: str          # warm / cool / neutral
    eye_color: str
    hair_color: str
    face_shape: str
    features: list[str]     # e.g. ["deep-set eyes", "strong brows"]


# ── Product / RAG ─────────────────────────────────────────────────────────────

class ProductCategory(str, Enum):
    foundation = "foundation"
    concealer = "concealer"
    blush = "blush"
    bronzer = "bronzer"
    highlighter = "highlighter"
    eyeshadow = "eyeshadow"
    eyeliner = "eyeliner"
    mascara = "mascara"
    lipstick = "lipstick"
    lip_gloss = "lip_gloss"
    earrings = "earrings"
    necklace = "necklace"
    bracelet = "bracelet"
    bag = "bag"
    nail_colour = "nail_colour"
    hair_accessory = "hair_accessory"


class Product(BaseModel):
    id: str
    name: str
    brand: str
    category: ProductCategory
    price_eur: float
    shades: list[str] = []
    finish: Optional[str] = None        # e.g. "matte", "satin", "dewy"
    undertone_fit: Optional[str] = None # "warm" / "cool" / "neutral" / "all"
    skin_tones: list[str] = []          # e.g. ["fair", "light", "medium"]
    occasions: list[str] = []
    url: str
    image_url: Optional[str] = None
    source: str                         # "sephora" | "asos" | "amazon"
    description: str = ""


# ── Recommendation ────────────────────────────────────────────────────────────

class Recommendation(BaseModel):
    category: str
    product: Optional[Product] = None   # None if no RAG match, LLM generates generic
    name: str                           # product name or LLM-suggested name
    detail: str                         # how to apply / wear
    reasoning: str                      # why it suits this person
    match_score: int = Field(ge=0, le=100)
    shade_suggestion: Optional[str] = None


# ── Full response ─────────────────────────────────────────────────────────────

class StyleResponse(BaseModel):
    look_title: str
    look_description: str
    attributes: list[str]
    visual_profile: VisualProfile
    color_story: ColorStory
    recommendations: list[Recommendation]
    stylist_note: str
    image_s3_key: Optional[str] = None
