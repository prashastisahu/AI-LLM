from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # Anthropic
    anthropic_api_key: str

    # AWS
    aws_access_key_id: str
    aws_secret_access_key: str
    aws_region: str = "eu-central-1"
    s3_bucket_name: str = "ai-stylist-images"

    # Database
    database_url: str

    # Redis
    redis_url: str = "redis://localhost:6379"

    # ChromaDB
    chroma_persist_dir: str = "./chroma_db"
    chroma_collection_name: str = "products"

    # App
    app_env: str = "development"
    log_level: str = "INFO"
    max_image_size_mb: int = 10

    # Vision model
    vision_model: str = "claude-opus-4-5"
    max_tokens: int = 2000

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
