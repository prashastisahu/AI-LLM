"""
API routes:
  POST /api/v1/style        — main: upload photo + prefs → StyleResponse
  GET  /api/v1/health       — health check
  POST /api/v1/products/ingest  — admin: ingest scraped products into ChromaDB
"""
import io
from fastapi import APIRouter, File, UploadFile, Form, HTTPException, Depends
from fastapi.responses import JSONResponse

from app.core.config import get_settings, Settings
from app.models.schemas import StyleRequest, StyleResponse, Occasion, Aesthetic, Budget
from app.services import stylist, rag

router = APIRouter(prefix="/api/v1")

ALLOWED_MEDIA_TYPES = {"image/jpeg", "image/png", "image/webp"}


@router.get("/health")
async def health():
    return {"status": "ok"}


@router.post("/style", response_model=StyleResponse)
async def analyse_style(
    image: UploadFile = File(..., description="User photo (JPEG/PNG/WEBP)"),
    occasion: Occasion = Form(Occasion.everyday),
    aesthetic: Aesthetic = Form(Aesthetic.natural),
    skin_tone_hint: str | None = Form(None),
    budget: Budget = Form(Budget.any),
    settings: Settings = Depends(get_settings),
):
    """
    Main endpoint: accepts a photo + style preferences,
    returns a full StyleResponse with visual profile + recommendations.
    """
    # Validate content type
    media_type = image.content_type or "image/jpeg"
    if media_type not in ALLOWED_MEDIA_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported image type '{media_type}'. Use JPEG, PNG, or WEBP.",
        )

    # Read and size-check
    image_bytes = await image.read()
    max_bytes = settings.max_image_size_mb * 1024 * 1024
    if len(image_bytes) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Image exceeds {settings.max_image_size_mb} MB limit.",
        )

    request = StyleRequest(
        occasion=occasion,
        aesthetic=aesthetic,
        skin_tone_hint=skin_tone_hint if skin_tone_hint else None,
        budget=budget,
    )

    try:
        result = await stylist.run_style_analysis(image_bytes, media_type, request)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {e}")

    return result


@router.post("/products/ingest")
async def ingest_products(products: list[dict]):
    """
    Admin endpoint: ingest a list of scraped product dicts into ChromaDB.
    Call this after running the scraper pipeline.
    Protect this endpoint with an API key in production.
    """
    try:
        count = rag.ingest_products(products)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"ingested": count}
