"""
Tests for the stylist pipeline.
Run: pytest tests/ -v
"""
import pytest
import json
from unittest.mock import AsyncMock, MagicMock, patch
from app.models.schemas import StyleRequest, Occasion, Aesthetic, Budget
from app.services import vision


MOCK_VISION_RESPONSE = {
    "look_title": "Warm Earth Goddess",
    "look_description": "Rich warm undertones with deep expressive eyes.",
    "attributes": ["warm", "radiant", "natural", "earthy"],
    "visual_profile": {
        "skin_tone": "medium-deep",
        "undertone": "warm",
        "eye_color": "dark brown",
        "hair_color": "dark brown",
        "face_shape": "oval",
        "features": ["almond eyes", "defined brows"],
    },
    "color_story": {
        "palette": [
            {"hex": "#C4956A", "name": "Warm Terracotta", "use": "blush"},
            {"hex": "#8B4513", "name": "Deep Sienna", "use": "eyes"},
        ],
        "description": "Warm amber and terracotta tones that complement golden undertones.",
    },
    "raw_recommendations": [
        {
            "category": "foundation",
            "name": "Skin Tint Medium Warm",
            "detail": "Apply with fingers for a natural finish.",
            "reasoning": "Matches warm medium-deep undertone perfectly.",
            "match_score": 92,
            "shade_suggestion": "Medium Warm W40",
            "search_query": "foundation medium warm skin tint natural finish",
        }
    ],
    "stylist_note": "Let your warmth lead every look.",
}


@pytest.mark.asyncio
async def test_vision_parse_visual_profile():
    vp = vision.parse_visual_profile(MOCK_VISION_RESPONSE)
    assert vp.undertone == "warm"
    assert vp.skin_tone == "medium-deep"
    assert "almond eyes" in vp.features


@pytest.mark.asyncio
async def test_vision_parse_color_story():
    cs = vision.parse_color_story(MOCK_VISION_RESPONSE)
    assert len(cs.palette) == 2
    assert cs.palette[0].hex == "#C4956A"


@pytest.mark.asyncio
async def test_full_pipeline_mock():
    """Integration test with mocked Anthropic + S3 + RAG."""
    from app.services import stylist

    mock_vision_data = MOCK_VISION_RESPONSE.copy()
    image_bytes = b"fake-image-bytes"
    media_type = "image/jpeg"
    request = StyleRequest(
        occasion=Occasion.everyday,
        aesthetic=Aesthetic.natural,
        budget=Budget.mid,
    )

    with (
        patch("app.services.stylist.s3.upload_image", return_value="uploads/test.jpg"),
        patch("app.services.stylist.vision.analyse_image", new=AsyncMock(return_value=mock_vision_data)),
        patch("app.services.stylist.rag.search_products", return_value=[]),
    ):
        result = await stylist.run_style_analysis(image_bytes, media_type, request)

    assert result.look_title == "Warm Earth Goddess"
    assert len(result.recommendations) == 1
    assert result.recommendations[0].category == "foundation"
    assert result.image_s3_key == "uploads/test.jpg"


def test_normalise_category():
    from app.services.stylist import _normalise_category
    assert _normalise_category("Lip Colour") == "lipstick"
    assert _normalise_category("Eye Shadow") == "eyeshadow"
    assert _normalise_category("Blush & Bronzer") == "blush"
    assert _normalise_category("Unknown stuff") is None
