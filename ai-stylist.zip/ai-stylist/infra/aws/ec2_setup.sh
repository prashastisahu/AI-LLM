#!/bin/bash
# EC2 User Data script — run on first boot (Amazon Linux 2023 or Ubuntu 22.04)
# Sets up the AI Stylist API with Nginx + Gunicorn + systemd

set -e

# --- System deps ---
apt-get update -y
apt-get install -y python3.11 python3.11-venv python3-pip nginx git

# --- App user ---
useradd -m -s /bin/bash stylist || true
mkdir -p /opt/ai-stylist
chown stylist:stylist /opt/ai-stylist

# --- Clone your repo (replace with your actual repo URL) ---
# git clone https://github.com/youruser/ai-stylist.git /opt/ai-stylist
# For now, assume code is already present at /opt/ai-stylist

su - stylist -c "
  cd /opt/ai-stylist
  python3.11 -m venv .venv
  source .venv/bin/activate
  pip install --upgrade pip
  pip install -r requirements.txt
  playwright install chromium
  playwright install-deps
"

# --- Systemd service ---
cat > /etc/systemd/system/ai-stylist.service << 'EOF'
[Unit]
Description=AI Stylist FastAPI App
After=network.target

[Service]
User=stylist
WorkingDirectory=/opt/ai-stylist
EnvironmentFile=/opt/ai-stylist/.env
ExecStart=/opt/ai-stylist/.venv/bin/gunicorn app.main:app \
    -k uvicorn.workers.UvicornWorker \
    --workers 2 \
    --bind 127.0.0.1:8000 \
    --timeout 120 \
    --access-logfile - \
    --error-logfile -
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ai-stylist
systemctl start ai-stylist

# --- Nginx config ---
cat > /etc/nginx/sites-available/ai-stylist << 'EOF'
server {
    listen 80;
    server_name _;  # Replace with your domain

    client_max_body_size 15M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;
    }
}
EOF

ln -sf /etc/nginx/sites-available/ai-stylist /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "✓ AI Stylist deployed"
