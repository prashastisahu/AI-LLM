#!/usr/bin/env python
"""
Full pipeline script: scrape → ingest into ChromaDB.

Usage:
    python scripts/run_pipeline.py --sources sephora --categories foundation,blush
    python scripts/run_pipeline.py --from-file scraped_sephora.json
"""
import asyncio
import json
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from scraper.sephora import scrape_all as sephora_scrape
from app.services.rag import ingest_products
import structlog

logger = structlog.get_logger()

ALL_CATEGORIES = [
    "foundation", "concealer", "blush", "bronzer", "highlighter",
    "eyeshadow", "eyeliner", "mascara", "lipstick", "lip_gloss",
]


async def main():
    parser = argparse.ArgumentParser(description="Scrape & ingest products")
    parser.add_argument("--sources", default="sephora", help="Comma-separated: sephora,asos")
    parser.add_argument("--categories", default=",".join(ALL_CATEGORIES))
    parser.add_argument("--max-per-category", type=int, default=100)
    parser.add_argument("--from-file", help="Skip scraping, ingest from JSON file")
    parser.add_argument("--save-raw", help="Save scraped JSON before ingestion")
    args = parser.parse_args()

    if args.from_file:
        logger.info("pipeline.load_file", path=args.from_file)
        products = json.loads(Path(args.from_file).read_text())
    else:
        categories = [c.strip() for c in args.categories.split(",")]
        sources = [s.strip() for s in args.sources.split(",")]
        products = []

        if "sephora" in sources:
            logger.info("pipeline.scrape_sephora", categories=categories)
            sephora_products = await sephora_scrape(categories, args.max_per_category)
            products.extend(sephora_products)
            logger.info("pipeline.sephora_done", count=len(sephora_products))

        # Add ASOS / Amazon scrapers here the same way:
        # if "asos" in sources:
        #     from scraper.asos import scrape_all as asos_scrape
        #     products.extend(await asos_scrape(categories, args.max_per_category))

    if args.save_raw:
        Path(args.save_raw).write_text(json.dumps(products, indent=2))
        logger.info("pipeline.raw_saved", path=args.save_raw, count=len(products))

    logger.info("pipeline.ingest_start", total=len(products))
    ingested = ingest_products(products)
    logger.info("pipeline.ingest_done", ingested=ingested)
    print(f"\n✓ Pipeline complete: {ingested} products in ChromaDB")


if __name__ == "__main__":
    asyncio.run(main())
